var searchData=
[
  ['khzsdclk',['kHzSdClk',['../class_sdio_card.html#a3532a1a4b8a43a51ed9b5853186203cb',1,'SdioCard']]]
];
